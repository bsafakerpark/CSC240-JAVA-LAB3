package java240lab3pac;

import java240lab2pac.CommissionCalculator;

public class Driver {
	    public static void main(String[] args) {
	        // Create commission calculator
	        CommissionCalculator calc = new CommissionCalculator();
	        
	        // Run commission calculator
	        calc.Run();
	    }
	}
