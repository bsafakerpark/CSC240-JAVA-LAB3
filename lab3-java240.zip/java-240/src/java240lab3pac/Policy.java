package java240lab3pac;

public abstract class Policy {
	

	    protected String firstName;
	    protected String lastName;
	       
	 
	    
	    
	    // Abstract method to be implemented by derived classes
	    public abstract double computeCommission();
	}

