package java240lab3pac;

import java.util.Scanner;

import java240lab3pac.Policy;

public class CommissionCalculator {
	private Auto autoPolicy;
	private Home homePolicy;
	private Life lifePolicy;
	
public CommissionCalculator() {
	autoPolicy = new Auto();
	homePolicy = new Home();
	lifePolicy = new Life();
	}
	   
public void Run() {
	Scanner scanner = new Scanner(System.in);
	int choice;
	do {
		System.out.println("-----------------------------");
		System.out.println("Welcome to Parkland Insurance");
	    System.out.println("-----------------------------");
	    System.out.println("Enter any of the following:");
	    System.out.println("1) Enter auto insurance policy information");
	    System.out.println("2) Enter home insurance policy information");
	    System.out.println("3) Enter life insurance policy information");
	    System.out.println("4) Compute commission and print auto policy");
	    System.out.println("5) Compute commission and print home policy");
	    System.out.println("6) Compute commission and print life policy");
	    System.out.println("7) Quit");
	    
	    choice = scanner.nextInt();
	    scanner.nextLine();  
	    
	    switch (choice) {
	    case 1:
	    	System.out.print("Enter first name of insured: "); 
	    	String firstName = scanner.nextLine();
	        System.out.print("Enter last name of insured: ");
	        String lastName = scanner.nextLine();
	        System.out.print("Enter make of vehicle: ");
	        String make = scanner.nextLine();
	        System.out.print("Enter model of vehicle: ");
	        String model = scanner.nextLine();
	        System.out.print("Enter amount of liability: $");
	        double liability = scanner.nextDouble();
	        System.out.print("Enter amount of collision: $");
	        double collision = scanner.nextDouble();
	        autoPolicy.enterPolicyInfo(firstName, lastName, make, model, liability, collision);
	        break;
	        
	    	case 2:
	        System.out.print("Enter first name of insured: ");
	        firstName = scanner.nextLine();
	        System.out.print("Enter last name of insured: ");
	        lastName = scanner.nextLine();
	        System.out.print("Enter house square footage: ");
	        int squareFootage = scanner.nextInt();
	        System.out.print("Enter amount of dwelling: $");
	        double dwelling = scanner.nextDouble();
	        System.out.print("Enter amount of contents: $");
	        double contents = scanner.nextDouble();
	        System.out.print("Enter amount of liability: $");
	        liability = scanner.nextDouble();
	        homePolicy.enterPolicyInfo(firstName, lastName, squareFootage, dwelling, contents, liability);
	        break;
	        
	        case 3:
	        System.out.print("Enter first name of insured: ");
	        firstName = scanner.nextLine();
	        System.out.print("Enter last name of insured: ");
	        lastName = scanner.nextLine();
	        System.out.print("Enter age of insured: ");
	        int age = scanner.nextInt();
	        System.out.print("Enter amount of term: $");
	        double term = scanner.nextDouble();
	        lifePolicy.enterPolicyInfo(firstName, lastName, age, term);
	        break;
	
	        case 4:
	        	autoPolicy.printPolicy();
	            break;
	            
	        case 5:
	            homePolicy.printPolicy();
                break;
                
	        case 6:
	        	lifePolicy.printPolicy();
	            break;
	            
	        case 7:
	        	System.out.println();
	            break;
	            
	        default:
	            System.out.println("Try one integer number between 1 and 7 (inclusive)");
	            }
	    } while (choice != 7);
	}

public double calculateTotalCommission(Policy[] policies) {
	// TODO Auto-generated method stub
	return 0;
}
}